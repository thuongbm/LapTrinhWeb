﻿namespace Lab1.Models
{
    public enum Gender
    {
        Male,
        Female
    }
}
