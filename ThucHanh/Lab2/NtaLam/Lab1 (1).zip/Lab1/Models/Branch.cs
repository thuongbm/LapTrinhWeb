﻿namespace Lab1.Models
{
    public enum Branch
    {
        IT,
        BE,
        CE,
        EE
    }
}
